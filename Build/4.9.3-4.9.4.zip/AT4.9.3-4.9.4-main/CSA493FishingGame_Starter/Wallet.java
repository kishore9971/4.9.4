/*
 * Activity 4.9.3
 */
public class Wallet extends LakeObject
{
    /*---------- methods ----------*/
  //added for step 16 4.9.3
  @Override
  public String say()
  {
    return "You now have a wallet!";
  }
}